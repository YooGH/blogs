import React, { Component } from 'react'

// 状态管理
import { Provider } from 'react-redux'
import configStore from './store'


import './app.scss'
import {
  url,
  webViewUrl
} from './config.js'
import {
  navigateWebView,
  redirectToWebView
} from './utils/util.js'


const store = configStore()

class App extends Component {
  taroGlobalData = {
    teamCode: '', // 扫码团队编码
    orgId: '', // 扫码机构id
    userInfo: {}, // 微信用戶信息
    customerInfo: wx.getStorageSync("customerInfo") || {revisitPatInfo: {}}, // 用户信息
    url, // 接口地址
    webViewUrl, // webview地址
    navigateWebView, // 跳转至webView回调方法【不关闭当前页面】
    redirectToWebView // 跳转至webView回调方法【关闭当前页面】  pjh 20220119
  }

 // 可以使用所有的 React 生命周期方法
 componentDidMount () {}
  // 对应 onLaunch
  onLaunch () {}

  // 对应 onShow
  componentDidShow () {}

  // 对应 onHide
  componentDidHide () {}

  componentDidCatchError () {}
  
  // this.props.children 是将要会渲染的页面
  // render () {
  //   return this.props.children
  // }

  render () {
    return (
      <Provider store={store}>
        {/* <Index /> */}
        {this.props.children}
      </Provider>
    )
  }

  
}

export default App

import Taro from '@tarojs/taro'

const app = Taro.getApp()

// 请求(参： 请求地址，请求方式：默认'POST'，等待, 扩展对象 )
const ApiFn = (url, data, method = 'POST', title = '加载中...',  object = {}) => {
  title &&
    Taro.showLoading({
      title
    })
  return new Promise((resolve, reject) => {
    let requestType = {
      POST: 'application/json',
      GET: 'application/x-www-form-urlencoded',
      POSTText: 'application/x-www-form-urlencoded'
    }
    let header = {
      'content-type': requestType[method],
      sessionKey: Taro.getStorageSync('sessionKey'),
      customerId: Taro.getStorageSync('customerId')
    }
    if (method === 'POSTText') {
      method = 'POST'
    }
    Taro.request({
      url: app.url + url,
      data,
      method,
      header,
      success(res) {
        console.log(res)
        title && Taro.hideLoading()
        if (Number(res.statusCode) === 200 && !Number(res.data.code)) {
          // code === 0
          resolve(res.data)
        } else if (
          Number(res.statusCode) === 200 &&
          Number(res.data.code) == 100
        ) {
          // code === 100 需登录
          Taro.reLaunch({
            url: '/pages/login/login/login'
          })
        } else {
          console.log(res)
          Taro.showToast({
            title: res.data.message || `服务器异常！`,
            icon: 'none',
            duration: 2000
          })
          reject(res)
        }
      },
      fail(error) {
        title && Taro.hideLoading()
        Taro.showToast({
          title: 'fail',
          icon: 'none',
          duration: 2000
        })
        reject(error)
      },
      ...object
    })
  })
}
export {
  ApiFn
}


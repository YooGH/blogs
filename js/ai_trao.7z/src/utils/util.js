const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

/** 
 * 时间戳转化为年 月 日 时 分 秒 
 * number: 传入时间戳 
 * format：返回格式，支持自定义，但参数必须与formateArr里保持一致 
 * needZero：月日是否需要前面补0
 */
function formatTimeTwo(number, format, needZero = true) {
  var formateArr = ['Y', 'M', 'D', 'h', 'm', 's'];
  var returnArr = [];
  if (number.toString().length < 13) {
    var date = new Date(number * 1000);
  } else {
    var date = new Date(number);
  }
  returnArr.push(date.getFullYear());
  returnArr.push(needZero ? formatNumber(date.getMonth() + 1) : date.getMonth() + 1);
  returnArr.push(needZero ? formatNumber(date.getDate()) : date.getDate());

  returnArr.push(formatNumber(date.getHours()));
  returnArr.push(formatNumber(date.getMinutes()));
  returnArr.push(formatNumber(date.getSeconds()));

  for (var i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i]);
  }
  return format;
}



/** 
 * 和PHP一样的时间戳格式化函数 
 * @param {string} format 格式 
 * @param {int} timestamp 要格式化的时间 默认为当前时间 
 * @return {string}   格式化的时间字符串 
 */
function date(format, timestamp) {
  var a, jsdate = ((timestamp) ? new Date(timestamp * 1000) : new Date());
  var pad = function (n, c) {
    if ((n = n + "").length < c) {
      return new Array(++c - n.length).join("0") + n;
    } else {
      return n;
    }
  };
  var txt_weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var txt_ordin = {
    1: "st",
    2: "nd",
    3: "rd",
    21: "st",
    22: "nd",
    23: "rd",
    31: "st"
  };
  var txt_months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  var f = {
    // Day 
    d: function () {
      return pad(f.j(), 2)
    },
    D: function () {
      return f.l().substr(0, 3)
    },
    j: function () {
      return jsdate.getDate()
    },
    l: function () {
      return txt_weekdays[f.w()]
    },
    N: function () {
      return f.w() + 1
    },
    S: function () {
      return txt_ordin[f.j()] ? txt_ordin[f.j()] : 'th'
    },
    w: function () {
      return jsdate.getDay()
    },
    z: function () {
      return (jsdate - new Date(jsdate.getFullYear() + "/1/1")) / 864e5 >> 0
    },

    // Week 
    W: function () {
      var a = f.z(),
        b = 364 + f.L() - a;
      var nd2, nd = (new Date(jsdate.getFullYear() + "/1/1").getDay() || 7) - 1;
      if (b <= 2 && ((jsdate.getDay() || 7) - 1) <= 2 - b) {
        return 1;
      } else {
        if (a <= 2 && nd >= 4 && a >= (6 - nd)) {
          nd2 = new Date(jsdate.getFullYear() - 1 + "/12/31");
          return date("W", Math.round(nd2.getTime() / 1000));
        } else {
          return (1 + (nd <= 3 ? ((a + nd) / 7) : (a - (7 - nd)) / 7) >> 0);
        }
      }
    },

    // Month 
    F: function () {
      return txt_months[f.n()]
    },
    m: function () {
      return pad(f.n(), 2)
    },
    M: function () {
      return f.F().substr(0, 3)
    },
    n: function () {
      return jsdate.getMonth() + 1
    },
    t: function () {
      var n;
      if ((n = jsdate.getMonth() + 1) == 2) {
        return 28 + f.L();
      } else {
        if (n & 1 && n < 8 || !(n & 1) && n > 7) {
          return 31;
        } else {
          return 30;
        }
      }
    },

    // Year 
    L: function () {
      var y = f.Y();
      return (!(y & 3) && (y % 1e2 || !(y % 4e2))) ? 1 : 0
    },
    //o not supported yet 
    Y: function () {
      return jsdate.getFullYear()
    },
    y: function () {
      return (jsdate.getFullYear() + "").slice(2)
    },

    // Time 
    a: function () {
      return jsdate.getHours() > 11 ? "pm" : "am"
    },
    A: function () {
      return f.a().toUpperCase()
    },
    B: function () {
      // peter paul koch: 
      var off = (jsdate.getTimezoneOffset() + 60) * 60;
      var theSeconds = (jsdate.getHours() * 3600) + (jsdate.getMinutes() * 60) + jsdate.getSeconds() + off;
      var beat = Math.floor(theSeconds / 86.4);
      if (beat > 1000) beat -= 1000;
      if (beat < 0) beat += 1000;
      if ((String(beat)).length == 1) beat = "00" + beat;
      if ((String(beat)).length == 2) beat = "0" + beat;
      return beat;
    },
    g: function () {
      return jsdate.getHours() % 12 || 12
    },
    G: function () {
      return jsdate.getHours()
    },
    h: function () {
      return pad(f.g(), 2)
    },
    H: function () {
      return pad(jsdate.getHours(), 2)
    },
    i: function () {
      return pad(jsdate.getMinutes(), 2)
    },
    s: function () {
      return pad(jsdate.getSeconds(), 2)
    },
    //u not supported yet 

    // Timezone 
    //e not supported yet 
    //I not supported yet 
    O: function () {
      var t = pad(Math.abs(jsdate.getTimezoneOffset() / 60 * 100), 4);
      if (jsdate.getTimezoneOffset() > 0) t = "-" + t;
      else t = "+" + t;
      return t;
    },
    P: function () {
      var O = f.O();
      return (O.substr(0, 3) + ":" + O.substr(3, 2))
    },
    //T not supported yet 
    //Z not supported yet 

    // Full Date/Time 
    c: function () {
      return f.Y() + "-" + f.m() + "-" + f.d() + "T" + f.h() + ":" + f.i() + ":" + f.s() + f.P()
    },
    //r not supported yet 
    U: function () {
      return Math.round(jsdate.getTime() / 1000)
    }
  };

  return format.replace(/[\ ]?([a-zA-Z])/g, function (t, s) {
    if (t != s) {
      // escaped 
      ret = s;
    } else if (f[s]) {
      // a date function exists 
      ret = f[s]();
    } else {
      // nothing special 
      ret = s;
    }
    return ret;
  });
}

function navigateWebView(params) {
  const {
    url,
    data = {},
    type = 'navigateTo'  // 跳转到一个应用内的某个页面，但是，保留着当前页面
  } = params;
  if (!url) throw Error('url不能为空');
  const webUrl = Object.entries(data).reduce((result, [key, value], index) => {
    return (result += `&${key}=${value}`);
  }, encodeURIComponent(url));
  wx[type]({
    url: `/pages/healthPassportWebShow/healthPassportWebShow?webUrl=${webUrl}`
  });
}

// pjh 20220119
function redirectToWebView(params) {
  const {
    url,
    data = {},
    type = 'redirectTo' // 关闭当前页面，跳转到应用内的某个页面。
  } = params;
  if (!url) throw Error('url不能为空');
  const webUrl = Object.entries(data).reduce((result, [key, value], index) => {
    return (result += `&${key}=${value}`);
  }, encodeURIComponent(url));
  wx[type]({
    url: `/pages/healthPassportWebShow/healthPassportWebShow?webUrl=${webUrl}`
  });
}


function handleSubscribeMessage(tmplIds) {
  return new Promise((resolve, reject) => {
    wx.requestSubscribeMessage({
      tmplIds,
      success: res => {
        resolve(res);
        console.log("订阅消息 成功 " + JSON.stringify(res));
      },
      fail: err => {
        reject(err)
        console.log("订阅消息 失败 " + JSON.stringify(err));
      }
    })
  })
}

function idCardForData(userCard, type = 'age') {
  if (!userCard) return null;
  if (type == 'age') {
    //获取年龄
    var myDate = new Date();
    var month = myDate.getMonth() + 1;
    var day = myDate.getDate();
    var age = myDate.getFullYear() - userCard.substring(6, 10) - 1;
    if (userCard.substring(10, 12) < month || userCard.substring(10, 12) == month && userCard.substring(12, 14) <= day) {
      age++;
    }
    return age;
  }
}

function getDay(day) {
  var today = new Date();
  var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
  today.setTime(targetday_milliseconds); //注意，这行是关键代码
  var tYear = today.getFullYear();
  var tMonth = today.getMonth();
  var tDate = today.getDate();
  tMonth = doHandleMonth(tMonth + 1);
  tDate = doHandleMonth(tDate);
  return tYear + "-" + tMonth + "-" + tDate;
}

function doHandleMonth(month) {
  var m = month;
  if (month.toString().length == 1) {
    m = "0" + month;
  }
  return m;
}
class Lock {
  constructor(value) {
    this.value = false;
  }
  change(value) {
    this.value = value
  }
}

/**
 * @description 正则校验
 * @param {String} type 正则枚举
 * @param {String} value 校验的值
 */

function checkPattern(type, value) {
  switch (type) {
    case 'phone':
      return /^1[3456789]\d{9}$/.test(value);
    case 'email':
      return /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
    case 'number':
      return /^[0-9]+/.test(value);
    case 'isDecimals':
      return /^([1-9][0-9]*)+(.[0-9]{1,2})?$/.test(value);
    case 'isInt':
      return /^([1-9][0-9]*)$/.test(value);
    case 'url':
      // eslint-disable-next-line no-case-declarations
      const urlReg = new RegExp(
        /^((https?|ftp|file):\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/
      );
      return urlReg.test(value);
    case 'chinaWord':
      return /^[\u4E00-\u9FA5]+$/.test(value);
    case 'idCard':
      // eslint-disable-next-line no-unused-vars,no-case-declarations
      const reg = new RegExp(
        '(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{2}$)'
      );
      return reg.test(value);
    case 'isLettersAddNum':
      return /^[0-9a-zA-Z]*$/.test(value);
  }
}

// 防抖
/**
 * @description 防抖
 * @param {Fn} fn 执行任务
 * @param {number} second 秒数(默认2秒)
 */
let timer = 0;
function debounceDate(fn, second = 0.8) {
  if((Date.now() - timer) > second * 1000) {
    timer = Date.now();
    fn();
    // console.log(Date.now())
  } else {
    // wx.showToast({
    //   title: '不要重复点击',
    // })
  }
}

// 防抖2
/**
 * @description 防抖
 * @param {Fn} fn 执行任务
 * @param {number} second 秒数(默认2秒)
 */
function debounce(fn, wait = 50, first = true) {
  let timer = null;
  let count = 0;
  return function(){
    console.log('count', count)
    if(!count && first) { // 第一次就执行
      count++
      fn.apply(this, arguments);
      timer = setTimeout(()=>{
        count = 0;
      },wait);
    }
    else {
      if(timer !== null){
        clearTimeout(timer);
      }
      count++
      timer = setTimeout(()=>{
        fn.apply(this, arguments);
        count = 0;
      },wait);
    }
   
  }
}
// 节流
/**
 * @description 节流
 * @param {Fn} fn 执行任务
 * @param {number} second 秒数(默认0.5秒)
 */
function throttle(fn, delay = 500) {
  let timer = null
  return function () {
    if (timer) { return }
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      clearTimeout(timer)
      timer = null
    }, delay)
  }
}

/**
 * 整合路由携带传参
 * @param { object } params
 */
function handleParams(params = {}) {
  return Object.entries(params).reduce((result, [key, value], index) => {
    return (result += `${index === 0 ? '' : '&'}${key}=${value}`);
  }, '');
}


// 自定义顶部导航栏，返回状态高度和导航栏高度以及底部安全高度
function getNavInfo() {
  const info = wx.getSystemInfoSync()
  console.log('系统信息', info)
  let [
    statusBar,
    customBar,
    safeAreaHeight,
    capsule,
    viewingHeight
  ] = [
    info.statusBarHeight,
    0,
    info.safeArea ? info.screenHeight - info.safeArea.bottom : 40,
    wx.getMenuButtonBoundingClientRect(),
    info.windowHeight
  ]
  if (capsule) {
    customBar = capsule.bottom + capsule.top - info.statusBarHeight;
  }
  return {
    viewingHeight,
    statusBar,
    customBar,
    safeAreaHeight
  }
}




export {
  handleParams,
  checkPattern,
  Lock,
  formatTime,
  formatTimeTwo,
  navigateWebView,
  redirectToWebView,
  handleSubscribeMessage,
  idCardForData,
  getDay,
  debounceDate,
  throttle,
  getNavInfo,
  debounce,
}
// export default obj1
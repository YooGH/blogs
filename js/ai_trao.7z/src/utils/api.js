export const getOrderDetail = 'api/PhysicalExamination/getExaminateOrderDetail'; // 根据订单编号，获取体检套餐订单详情
export const createOrder = 'api/PhysicalExamination/examinateOrderCreate'; // 创建订单（mdt,个检, 团检）
export const createEvaluate = 'api/PhysicalExamination/createEvaluate'; // 创建mdt评估
export const orderPayQueryExecute = 'api/OrderController/orderPayQueryExecute'; // 查询订单支付信息 （并且执行支付成功的操作）
export const getCanPayMdtOrder = 'api/PhysicalExamination/getCanPayMdtOrder'; // 判断是否可以支付mdt订单
export const getMdtPackageList = 'api/PhysicalExamination/getMdtPackageList'; // AIMDT套餐



// medical(cjr)
export const subscribeExamination = 'api/PhysicalExamination/subscribeExamination'; // 体检套餐预约接口
export const subscribeExaminationVerify = 'api/PhysicalExamination/subscribeExaminationVerify'; // 体检套餐预约校验接口
export const getGroupUserList = 'api/PhysicalExamination/getGroupUserList'; // 获取团体成员
export const verificationGroupUser = 'api/PhysicalExamination/verificationGroupUser'; // 验证预约信息是否可以预约并且发验证码
export const getMyMedicalReportListV2 = 'api/PhysicalExamination/getMyMedicalReportListV2'; // 小程序体检订单我的报告列表V2(xlj)
export const getMyMedicalReportListOffline = 'api/PhysicalExamination/getMyMedicalReportListOffline'; // 小程序获取医院线下体检报告列表(xlj)
export const helpMeUpload = 'api/activation/code/helpMeUpload'; // 帮我上传报告(xlj)
export const getAppointmentDateInfo = 'api/PhysicalExamination/getAppointmentDateInfo'; // 获取具体的预约日期(xlj)

// 问卷（xlj）
export const getQuestionnaireMsg = 'api/evaluateInfo/getQuestionnaireMsg'; // 获取最新进行心理/睡眠问卷的人数和头像
export const getQuestionnaire = 'api/evaluateInfo/getQuestionnaire'; // 获取心理/睡眠问卷
export const appraisalQuestion = 'api/evaluateInfo/appraisalQuestion'; // 提交心理/睡眠问卷
export const getHealthAppraisal = 'api/evaluateInfo/getHealthAppraisal'; // 获取心理/睡眠问卷测评数据


// 报告(cjr)
export const initEvaluateCount = 'api/v2/initEvaluateCount'; // 评估计数
export const getNucleateList = 'api/PhysicalExamination/getNucleateList'; // 核酸报告列表查询
export const getNucleateDetail = 'api/PhysicalExamination/getNucleateDetail'; // 核酸报告详情查询


// xlj&cjr
export const getSmsVCodeByMedicalReport = 'api/PhysicalExamination/getSmsVCodeByMedicalReport'; // 查看体检套餐报告获取验证码
// export const getMyMedicalReportList = 'api/PhysicalExamination/getMyMedicalReportList'; // 小程序体检订单我的报告列表
// export const getMyMedicalReportList = 'api/PhysicalExamination/getMyMedicalReportListV2'; // 小程序体检订单我的报告列表

export const exportUserByEmail = 'api/healthPassport/exportUserByEmail'; // 用户信息邮件导出（mq）
export const getFirstLoginStatus = 'api/healthPassport/getFirstLoginStatus'; // 判断用户首次登录（mq）
export const updateAuthStatus = 'api/healthPassport/updateAuthStatus'; // 修改登录状态（mq）


export const getKfUrl = 'api/kf/getKfUrl'; // 根据机构id获取客服url，默认返回第一个（lgy）
export const changeEvaluateLogin = 'api/healthPassport/changeEvaluateLogin'; // 根据手机号切换评估登录（ly）

export const getFamilyMemberList = 'api/family/getFamilyMemberList'; // 获取我的家人列表（ld）
export const getFamilyMemberInfo = 'api/family/getFamilyMemberInfo'; // 获取我的家人详情（ld）
export const addFamilyMember = 'api/family/addFamilyMember'; // 获取代理人所有报告（ld）
export const getALlReport = 'api/report/getALlReport'; // 获取代理人所有报告（ld）
export const getPatientInSamePhone = 'api/report/getPatientInSamePhone'; // 根据手机号关联患者列表（ld）
export const checkPhoneCode = 'api/valid/checkPhoneCode'; // 校验手机验证码（ld）
export const changeOrgSaveFamilyMember = 'api/family/changeOrgSaveFamilyMember'; // 加入机构创建本人信息（ld）
export const getInfoByPatientId = 'api/v2/getInfoByPatientId'; // 根据患者ID查询患者信息接口（ld）

export const switchReportV2 = 'api/healthPassport/switchReportV2'; // 根据患者ID查询患者信息接口（oldapi）

export const saveBuryPoint = 'api/buryPoint/save'; // 新增数据埋点统一接口(wl)

export const findHealthTaskConf = 'api/customer/findHealthTaskConf'; // 健康任务提醒设置-查询(ld)
export const saveHealthTaskConf = 'api/customer/saveHealthTaskConf'; // 健康任务提醒设置-修改(ld)
export const changeAppointmentTime = 'api/PhysicalExamination/changeAppointmentTime'; // 修改-预约时间(ld)
export const confirmPhysicalExaminationItems = 'api/PhysicalExamination/confirmPhysicalExaminationItems'; // 【预约信息前置】确认体检项目页列表(xlj2.20)



export const getDepartmentsList = 'api/PhysicalExamination/getDepartmentsList'; // 获取机构科室列表接口(xlj2.20)
export const getExaminationItemList = 'api/PhysicalExamination/getExaminationItemList'; // 获取体检套餐加项列表接口(xlj2.20)
export const getExaminationItemConflictList = 'api/PhysicalExamination/getExaminationItemConflictList'; // 获取体检套餐加项冲突列表接口(xlj2.20)
export const orderExaminationItem = 'api/PhysicalExamination/orderExaminationItem'; // 体检套餐加项预订单接口返回订单金额给前端(xlj2.20)
export const payExaminationItem = 'api/PhysicalExamination/payExaminationItem'; // 体检套餐加项预订单接口(xlj2.20)
export const lockedInventory = 'api/PhysicalExamination/lockedInventory'; // 个检预约锁定库存并检查商品状态(xlj2.20)


export const updateCustomerAgent = 'api/customer/updateCustomerAgent'; // 2.20






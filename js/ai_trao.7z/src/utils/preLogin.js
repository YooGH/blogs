import Taro from '@tarojs/taro'

import {
  ApiFn
} from './request.js'

import {
  getFirstLoginStatus,
  updateAuthStatus,
  changeOrgSaveFamilyMember,
  switchReportV2,
  saveBuryPoint,
} from './api.js'

// import {
//   handleParams,
// } from './util.js'

const appData = Taro.getApp()

// 是否是第一次登录方法
const preLogin = (phone, verifyCode) => {
  return new Promise((resolve, reject) =>{
    if(!/^1(3|4|5|6|7|8|9)\d{9}$/.test(phone)) {
      Taro.showToast({
        title: '请填写正确的手机号！',
        icon: 'none',
        duration: 2000
      })
      reject(false)
      return false;
    }
    if(verifyCode.toString().length < 4) {
      Taro.showToast({
        title: '验证码错误！',
        icon: 'none',
        duration: 2000
      })
      reject(false)
      return false;
    }    
    const params = {
      phone,
      verifyCode
    }
    ApiFn(
      getFirstLoginStatus,
      params,
      "POST"
    ).then(res=>{
      resolve(res.result)
    }).catch(err=>{
      reject(err)
    })
  })
}

// 更新第一次登录状态

const updateAuthStatusFn = (phone, authStatus = 1) => {
  return new Promise((resolve, reject) =>{
    if(!/^1(3|4|5|6|7|8|9)\d{9}$/.test(phone)) {
      Taro.showToast({
        title: '请填写正确的手机号！',
        icon: 'none',
        duration: 2000
      })
      reject(false)
      return false;
    }
    ApiFn(
      updateAuthStatus,
      {
        phone,
        authStatus
      },
      "POST"
    ).then(res=>{
      resolve(res.result)
    }).catch(err=>{
      reject(err)
    })
  })
}

// 跳转指定页面: 未登录时，先登录后跳回指定页面
// 先获取机构id，再跳转(如果登录信息有返回机构id，就可以省略这步)
const preRoute = (route, type) => {
  return new Promise((resolve, reject) =>{
    // console.log(appData.routeObj)
    const whiteList = [
      'pages/scantheloginxieyi/scantheloginxieyi',
      'pages/scanthelogin/scanthelogin',
      'pages/serviceCard/serviceCard'
    ]
    if(type !== 'selectTwo') {
      channelInfoFn();
    }

    if(appData.routeObj && appData.routeObj.options.type === 'join') { // 外联默认带机构加入
      let paramsOrgId = appData.routeObj.options.orgid || appData.routeObj.options.orgId;
      paramsOrgId && ApiFn(
        "api/healthPassport/getNewestOrgCustomerAgentUpdate", {
          orgId: paramsOrgId
        },
        'POST',
        ''
      ).then(res => {
        Taro.setStorageSync('orgId', res.result.orgPitch)
        orgIdToMemberFn();
        // 获取并拼接参数为字符串参数，拼接在指定路径后
        let jumpRouteQuery = JSON.parse(JSON.stringify(appData.routeObj.options))
        let { orgid, orgId, route, type, ...rest } = jumpRouteQuery;
        const queryStr = Object.entries(rest).reduce((result, [key, value], index) => {
          return (result += `${index > 0 ? '&' : '?'}${key}=${value}`);
        }, '')
        Taro.reLaunch({
          url: `${appData.routeObj.options.route}${queryStr}`,
          success(){
            appData.routeObj = null
          }
        })
        resolve(true)
      })
    } else if (appData.routeObj && appData.routeObj.options.type === 'view') {
      // 获取并拼接参数为字符串参数，拼接在指定路径后
      let jumpRouteQuery = JSON.parse(JSON.stringify(appData.routeObj.options))
      let { orgid, orgId, route, type, ...rest } = jumpRouteQuery;
      const queryStr = Object.entries(rest).reduce((result, [key, value], index) => {
        return (result += `${index > 0 ? '&' : '?'}${key}=${value}`);
      }, '')
      Taro.reLaunch({
        url: `${appData.routeObj.options.route}${queryStr}`,
        success(){
          appData.routeObj = null
        }
      })
    } else {
      route && Taro.reLaunch({
        url: route
      })
      reject(false)
    }
  })
}


// 渠道埋点判断
const channelInfoFn = (operateType = 17) => {
  let channelInfo = Taro.getStorageSync('channelInfo');
  if(channelInfo && !channelInfo['require']) { // 公众号和SCRM首次登录
    saveBuryPointFn({
      ...channelInfo,
      operateType, // 默认登录类型（17）,注册类型（5）
      pointType: 2,
    }, operateType === 17 ? 'first' : '');
    if(operateType === 17){
      channelInfo.require = 1
      Taro.setStorageSync('channelInfo', channelInfo);
    }
  } else {
    saveBuryPointFn({
      operateType, // 登录类型
      pointType: 2,
      channelType: 3,
    })
  }
}

// 加入机构生成本人患者信息
const orgIdToMemberFn = (orgId) => {
  return new Promise((resolve, reject) =>{
    ApiFn(
      changeOrgSaveFamilyMember,
      {
        mobile: Taro.getStorageSync('phoneNumber'),
        orgId: orgId || Taro.getStorageSync('orgId') || '999'
      },
      'POST',
      ''
    ).then(res => {
      resolve(res.result && res.result.patientId)
      // console.log('加入机构生成本人患者信息')
    }).catch(err => {
      reject(err)
    })
  })
}

// 切换评估
const switchReportFn = (info, callback) => {
  console.log('infoo', )
  let loginInfo = Taro.getStorageSync('loginInfo');
  const params = {
    sessionKey: Taro.getStorageSync("sessionKey"),
    phoneNumber: Taro.getStorageSync("phoneNumber"),
    orgId: info.orgId,
    openId: loginInfo.miniOpenId,
    unionId: loginInfo.unionId,
    patientId: info.patientId,
    vid: info.vid,
    evaluateId: info.evaluateId,
  };
  Taro.setStorageSync('evaluateIdInfo', info);
  ApiFn(
    switchReportV2,
    params
  ).then(res=>{
    Taro.setStorageSync("customerId", res.result.customerId);
    Taro.setStorageSync("evaluateId", res.result.evaluateId);
    Taro.setStorageSync("evaluateType", res.result.type); // 评估类型
  
    //  pjh 2022-01-07 已跟后端确认
    //  评估类型 evaluateType 的解释如下：
    //  0 ：完整 aimdt 评估
    //  1 ：膳食评估 【针对南大菲特用户】
    //  2 ：单病种_高血压评估
    //  3 ：单病种_糖尿病评估
    //  4 ：糖尿病简化版
    //  99 ：aimdt无问卷版本
    if(info.type === 'select' || info.type === 'selectTwo') { // 列表有多个的(登录和登录后)
      preRoute(`/pages/index/index?vids=${info.vid}`, info.type)
    } else { // 列表只有一个的
      callback && callback(info.vid);
    }
  })
}




// 渠道进来埋点
const saveBuryPointFn = (info, type) => {
  if(!Taro.getStorageSync('customerId') || !Taro.getStorageSync('sessionKey')){ return }
  let [
    patientId,
    orgId
  ] = [
    Taro.getStorageSync('patientId'),
    info.orgId || info.orgid || Taro.getStorageSync('orgId'), // 机构跟评估走，没有的就那传进来或缓存
  ]
  if(!patientId && type != 'getPatientId') { // 登录没有患者id，先生成患者id后埋点
    orgIdToMemberFn(orgId).then(patientId=>{
      if(patientId) {
        let loginInfo = Taro.getStorageSync('loginInfo')
        loginInfo.patientId = patientId
        Taro.setStorageSync('loginInfo', loginInfo)
        Taro.setStorageSync('patientId', patientId)
        saveBuryPointFn(info, 'getPatientId')
      }
    })
  }
  if(!info.pointType || !info.operateType || !info.channelType || !patientId) {
    console.log('pointType,operateType,channelType不能为空')
    return
  }

  const params = {
    sessionKey: Taro.getStorageSync('sessionKey'),
    customerId: Taro.getStorageSync('customerId'),
    phone: Taro.getStorageSync('phoneNumber'),
    pointType: info.pointType,
    operateType: info.operateType,
    channelType: info.channelType,
    shareCreateId: info.shareCreateId,
    shareCreateName: info.shareCreateName,
    unionId: info.unionId,
    shareCode: info.shareCode,
    patientId, // 当前机构的代理人patientId
    orgId, // 
    // orderRefundMoney  dayTime  year  month  orgName   patientName    createdAt  parentId  packageId  packageName  bodySoftReportCount  createTimeStamp  evaluateId
  };
  ApiFn(
    saveBuryPoint,
    params,
    'POST',
    ''
  ).then(res=>{
    switch(type) {
      case 'first':
        Taro.setStorageSync('channelInfo', info);
        break;
      case 'loggedIn': // 已登录
        let channelInfo = Taro.getStorageSync('channelInfo')
        if(channelInfo) {
          channelInfo.require = 1;
          Taro.setStorageSync('channelInfo', channelInfo);
        }
        break;
    }
  })
}

// 保存登录信息(目前不保存vids字段) 2.17
const setLoginInfoFn = (info) => {
  let {
    vids,
    ...loginInfo
  } = info;
  // console.log('loginInfo', loginInfo)
  Taro.setStorageSync('loginInfo', loginInfo)
}


export {
  preLogin,
  updateAuthStatusFn,
  preRoute,
  orgIdToMemberFn,
  switchReportFn,
  saveBuryPointFn,
  setLoginInfoFn,
  channelInfoFn,
};

const app = getApp();
import request from './request.js';


// 登录方法封装   phoneNumber:电话号码   verifyCode:验证码 vid:体检编号
function gotoLogin(phoneNumber, verifyCode,vid) {
  if (!phoneNumber || !verifyCode ||!vid) {
    wx.showToast({
      title: '参数不全',
      icon: 'none'
    })
    return
  }
  return new Promise((resolve, reject) => {
    wx.login({
      success(res) {
        console.log(res.code)
        const accountInfo = wx.getAccountInfoSync();
        const params = {
          phoneNumber,
          verifyCode,
          vid,
          code: res.code,
          appId: accountInfo.miniProgram.appId
        }
        request.postRequest('api/healthPassport/register', params,
          function (res) {
            let messageShow = '登录成功'
            const title = res.code == '0' ? messageShow : res.message
            wx.showToast({
              title,
              icon: 'none',
              duration: 2000
            })

            wx.setStorageSync('sessionKey', res.result.sessionKey)
            wx.setStorageSync('customerId', res.result.customerId)


            if (res.result.status.indexOf('continue') != -1) {
              messageShow = ''
            }

            if (res.result.status.indexOf('continue') != -1) { //跳转填写性别名字
              wx.navigateTo({
                url: '/pages/scantheSexAndName/scantheSexAndName'
              })

            } else { //跳转欢迎使用界面
              wx.reLaunch({
                url: '/pages/healthPassportTwo/healthPassportTwo'
              })
            }

            if (res.code === "0") {
              resolve(res.data)
            } else {
              reject(res)
            }

          }, function (res) {
            console.log("失败" + res)
            reject(res)
          })
      },
      fail() {
        reject();
      }
    })
  })
}

export default gotoLogin;
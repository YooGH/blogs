import util from "./util.js";
import Taro from '@tarojs/taro'

const app = Taro.getApp()


/**
 * url:请求的url
 * params:请求参数
 * message:loading提示信息
 * success:成功的回调
 * fail:失败的回调
 */

//post请求
const postRequest = (url, params, success, fail) => {
  this.postRequestLoading(url, params, "", success, fail);
}

//根据判断message 是否显示loading
const postRequestLoading = (url, params, message, success, fail) => {
  if (message != "") {
    Taro.showLoading({
      title: message,
    });
  }

  // console.log(app.url + url + JSON.stringify(params));
  console.log( app.url + url)

  const postRequestTask = Taro.request({
    url: app.url + url,
    data: params,
    header: {
      "content-type": "application/x-www-form-urlencoded",
      sessionKey: Taro.getStorageSync("sessionKey"),
      customerId: Taro.getStorageSync("customerId"),
    },
    method: "POST",
    success: function (res) {
      if (message != "") {
        Taro.hideLoading();
      }
      if (res.statusCode === 200) {
        // console.log(JSON.stringify(res.data));
        success(res.data);
        routerLogin(res.data);
      } else {
        fail(res);
      }
    },
    fail: function (res) {
      console.log(res)
      if (message != "") {
        Taro.hideLoading();
      }
      fail(res);
    },
  });
}

//根据判断message 是否显示loading
const postRequestLoadingForJson = (url, params, message, success, fail) => {
  if (message != "") {
    Taro.showLoading({
      title: message,
    });
  }

  // console.log(app.url + url + JSON.stringify(params));

  const postRequestTask = Taro.request({
    url: app.url + url,
    data: params,
    header: {
      "content-type": "application/json",
      sessionKey: Taro.getStorageSync("sessionKey"),
      customerId: Taro.getStorageSync("customerId"),
    },
    method: "POST",
    success: function (res) {
      if (message.length > 0) {
        Taro.hideLoading();
      }
      if (res.statusCode === 200) {
        // console.log(JSON.stringify(res.data));
        success(res.data);
        routerLogin(res.data);
      } else {
        // console.log(res);
        fail(res);
      }
    },
    fail: function (res) {
      if (message != "") {
        Taro.hideLoading();
      }
      fail(res);
    },
  });
}

//get请求
const getRequest = (url, params, success, fail) => {
  this.getRequestLoading(url, params, "", success, fail);
}

const getRequestLoading = (url, params, message, success, fail) => {
  if (message.length > 0) {
    Taro.showLoading({
      title: message,
    });
  }


  const getRequestTask = Taro.request({
    url: app.url + url,
    data: params,
    header: {
      "content-type": "application/x-www-form-urlencoded",
      sessionKey: Taro.getStorageSync("sessionKey"),
      customerId: Taro.getStorageSync("customerId"),
    },
    method: "GET",
    success: function (res) {
      if (message != "") {
        Taro.hideLoading();
      }
      if (res.statusCode === 200) {
        // console.log(JSON.stringify(res.data));
        success(res.data);
        routerLogin(res.data);
      } else {
        fail(res);
      }
    },
    fail: function (res) {
      // console.log("error", res);
      if (message != "") {
        Taro.hideLoading();
      }
      fail(res);
    },
  });
}

//取消post请求
const abortPostRequest = (url, params, success, fail) => {
  postRequestTask.abort();
}

//取消get请求
const abortGetRequest = (url, params, success, fail) => {
  getRequestTask.abort();
}

// 判断状态码
function routerLogin(res) {
  // 判断没有客户信息就是没有登录
  const customerInfo = Taro.getStorageSync("customerInfo") || {};
  const keySync = Taro.getStorageSync("diseaseKey"); // 单病种
  if (!Object.keys(customerInfo).length) return;
  const { code, message } = res;

  // 非登录失效
  if (code !== "100") {
    // 小程序用户在（上）线通知
    const onlineDate = Taro.getStorageSync("onlineDate");
    onlineNotice(onlineDate);
    return;
  }

  // 登录失效，重新登录
  Taro.showToast({
    title: message || "登录失效，请重新登录",
    icon: "none",
    duration: 5000,
  });
  let timer = setTimeout(() => {
    Taro.clearStorageSync();
    if (keySync) {
      Taro.setStorageSync("diseaseKey", keySync);
      Taro.reLaunch({
        url: "/pages/scantheloginDisease/scantheloginDisease",
      });
    } else {
      Taro.reLaunch({
        url: "/pages/scantheloginxieyi/scantheloginxieyi",
      });
    }

    clearTimeout(timer);
  }, 2500);
}

// 小程序用户在（上）线通知,一天只请求一次
function onlineNotice(date) {
  if (date !== util.getDay(0)) {
    // url, params, success, fail
    const url = "api/customerInfo/onlineNotice";
    const params = { evaluateId: Taro.getStorageSync("evaluateId") };
    getRequestLoading(
      url,
      params,
      "",
      function (res) {
        // console.log("成功" + JSON.stringify(res));
        // 记录今天日期，用来拦截当天重复请求
        Taro.setStorageSync("onlineDate", util.getDay(0));
      },
      function (res) {
        // console.log("失败" + res);
      },
    );
  }
}

// 埋点请求
const toBuriedPoints = (num, patientId) => {
  // 埋点请求
  let type = {
    1: "d2282c1c-6f46-4118-9d51-d094c40e002f", // 小程序登录
    2: "cdad8e84-9930-49ec-93d3-b9cbd3179b48", // 激活码完成激活
    3: "3de28b70-390a-4e68-88f4-b82e07491c5a", // 激活码登录
    4: "9e1ec749-c124-47c7-80b1-dbb0fc7a75c8", // 激活码上传体检报告
  };
  const params = {
    buriedPointTypeId: type[num],
    patientId,
    remark: "",
  };
  this.postRequestLoadingForJson(
    "api/addBuriedDataPoints",
    params,
    function () {
      // console.log("埋点请求", res);
    },
    function () {
      // console.log("失败" + res);
    },
  );
}

export {
  postRequest,
  postRequestLoading,
  getRequest,
  getRequestLoading,
  abortPostRequest,
  abortGetRequest,
  postRequestLoadingForJson,
  toBuriedPoints,
};

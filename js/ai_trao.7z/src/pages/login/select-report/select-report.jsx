import { useState, useEffect } from 'react';
import Taro, {useDidShow, getCurrentInstance} from '@tarojs/taro'
import { Block, View, Image } from '@tarojs/components'
import './select-report.scss'
import {
  switchReportFn
} from '../../../utils/preLogin.js'
import configStore from '../../../store'

const store = configStore();

export default function LoginPhone(option) {
  const [type, setType] = useState(''); // info(个人)、''(登录)
  const [reportList, setReportList] = useState([]);
  const iconPath = 'https://yjk-aimdt-dev.obs.cn-south-1.myhuaweicloud.com/ImageFiles/resource-new/img/right.png';
  console.log('e', option)
  let instance = getCurrentInstance();
  useEffect(()=>{
    const _vids = store.getState().user.vidsList;
    setReportList(_vids)
    console.log('reportList', reportList)
    setType(instance.router.params.type)
  }, [])

  useDidShow(()=>{
  })
  const selectMealLogin = (info)=> {
    console.log('info', info)
    // 埋点请求
    Taro.setStorageSync('patientId', info.patientId)
    // request.toBuriedPoints(1, info.patientId)
    console.log('dd', {
      type: type === 'info' ? 'selectTwo' : 'select',
      ...info,
      info: info,
      vid: info.vid || info.activationCode,
      evaluateId: info.evaluateId || '',
    })
    switchReportFn({
      type: type === 'info' ? 'selectTwo' : 'select',
      ...info,
      info: info,
      vid: info.vid || info.activationCode,
      evaluateId: info.evaluateId || '',
    })
  }
  
 
  return (
    <Block>
      <View class='report-main'>
        <View class='report-title'>您有多份AI-MDT报告，请选择体检编号登录</View>
        {
          reportList.map(item => 
            <View
              key={item.vid}
              class='report-item'
              onClick={() =>selectMealLogin(item)}
            >
              { item.vid
                  ? <View class='special-font'>体检编号：{item.vid} </View>
                  : <View class='special-font'>激活码：{item.activationCode}</View>}
              <View class='deafult-font'>客户姓名：{item.name}</View>
              <View class='deafult-font'>创建时间：{item.date}</View>
              <Image class='icon-right' src={iconPath} />
            </View>
          )
        }
      </View>
    </Block>
  )
}

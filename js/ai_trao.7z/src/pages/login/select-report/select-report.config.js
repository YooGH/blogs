export default definePageConfig({
  navigationBarTitleText: '选择报告'
})

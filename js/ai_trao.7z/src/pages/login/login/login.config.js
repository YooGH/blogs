export default definePageConfig({
  navigationBarTitleText: '登录',
  navigationStyle: "custom", 
})

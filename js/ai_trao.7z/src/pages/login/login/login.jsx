import { useState } from 'react';
import { Block, Image, View, Button } from '@tarojs/components'
import Taro, {useDidShow} from '@tarojs/taro'
import './login.scss'

import {
  ApiFn
} from '../../../utils/request'
import configStore from '../../../store'

const store = configStore();


const app = Taro.getApp();

export default function Login() {
  // 声明一个新的叫做 “count” 的 state 变量
  const [isSelect, setIsSelect] = useState(false);
  const [opacity, setOpacity] = useState(0.4);
  const [TaroCode, setTaroCode] = useState('');
  const [templateIds, setTemplateIds] = useState([]); // 消息模板数组
  const [isClick, setIsClick] = useState(true); // 锁
  
 
  useDidShow(() => {
    getTaroCode()
    getFindTemplate()
  })

  const toScan = ()=> {
  }
  // 获取模板权限
  const getFindTemplate = ()=>{
    //通过接口获取订阅消息
    const accountInfo = Taro.getAccountInfoSync()
    const params = {
      appId: accountInfo.miniProgram.appId
    }
    ApiFn(
      'api/findTemplate',
      params,
      'GET',
      '加载中...'
    ).then(res=> {
      // console.log("获取消息模板接口" + JSON.stringify(res));
      if (res.result) {
        Taro.setStorageSync('templateList', res.result)
        const loginNeedTemplateType = [
          'QUESTION_ONE',
          'REPORT_SUCCESS',
          'CONSULTATION_PROGRESS'
        ] // 登录后需要获取的消息模板type

        const templateIdsList = res.result
          .filter(item => loginNeedTemplateType.includes(item.type))
          .map(item => item.templateId)
        setTemplateIds(templateIdsList)
        return
      }
      setTemplateIds([])
    })
  }
  // 获取微信code
  const getTaroCode = ()=>{
    Taro.login({
      success(res) {
        setTaroCode(res.code)
      }
    })
  }
  const policyFn = (e,type)=> {
    e.stopPropagation();
    console.log(type)
    return false;
    // let policyList = {
    //   agreement: 'agreement/view/agreement',
    //   privacy: 'privacy-agreement/view/privacy-agreement',
    // }
    // app.navigateWebView({
    //   url: `pages/h5/${policyList[type]}`
    // })
  }
  const showError = ()=> {
    if (!isSelect) {
      return Taro.showToast({
        title: '请阅读并同意《用户服务协议》与《隐私政策》',
        icon: 'none',
        duration: 2000
      })
    }
  }
  // 协议勾选
  const selectedFn = () => {
    setIsSelect(!isSelect)
    setOpacity(!isSelect ? 1.0 : 0.4)
  }
  // 登录
  const getPhoneNumberFn = (e)=> {
    console.log('增加获取手机号的功能', e)
    const that = this
    const accountInfo = Taro.getAccountInfoSync()
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
      const params = {
        appId: accountInfo.miniProgram.appId,
        data: e.detail.encryptedData,
        iv: e.detail.iv,
        code: TaroCode
      }
      ApiFn(
        'api/healthPassport/newLoginVoluntarily',
        params,
        'POSTText',
        '加载中...'
      ).then(res=>{
        console.log(res)
        const message = '登录成功'
        Taro.showToast({
          title: res.code == 0 ? message : res.message,
          icon: 'none',
          duration: 2000
        })
        const { mobile, sessionKey, status, vids, customerId } = res.result
        if (res.code == 0) {
          Taro.setStorageSync('sessionKey', sessionKey)
          Taro.setStorageSync('phoneNumber', mobile)
          if (res.result.perfectInfo) {
            // 信息不全需补齐
            return that.router2fillInfo(mobile)
          }
          if (status.indexOf('continue') != -1) {
            //跳转填写性别名字
            Taro.navigateTo({
              url: '../scantheSexAndName/scantheSexAndName'
            })
          } else {
            //跳转欢迎使用界面
            if (!vids?.length) {
              if (!customerId) {
                that.router2fillInfo(mobile)
                return
              } else {
                Taro.setStorageSync('newCustomerId', customerId)
                Taro.setStorageSync('customerId', customerId)
                Taro.reLaunch({
                  url: '/pages/index/index'
                })
              }
            }
            // 当扫码含有vid时直接使用vid
            if (vids?.length === 1) {
              const vid =
                that.data.vid ||
                vids[0].vid ||
                Taro.getStorageSync('phoneNumber') // 空数组拦截  1直接进欢迎页 1以上去选择套餐
              Taro.setStorageSync('evaluateId', vids[0].evaluateId) // 增加评估id的缓存 取第一个
              // 埋点请求
              // toBuriedPoints(1, vids[0].patientId)
              that.subscribeMessage(vid)
            } else if (vids?.length > 1) {
              console.log('vids大于2')

              store.dispatch({
                type: 'INCREASE',
                vids: vids
              })

              // Taro.reLaunch({
              Taro.reLaunch({
                url: '/pages/login/select-report/select-report'
              })
            }
          }
        }
      }).catch(err=>{
        console.log(err)
        if (err.data.code != 0 && err.data.mobile) {
          that.router2fillInfo(err.data.mobile)
        }
      }).finally(()=>{
        getTaroCode()
      })
    } else if (
      e.detail.errMsg.includes('getPhoneNumber:fail') &&
      e.detail.errMsg.includes('deny')
    ) {
      // ios(getPhoneNumber:fail user deny)
      // 安卓(getPhoneNumber:fail auth deny)
      // 安卓和ios返回空格不同
      gotoLogin()
    }
  }
  //去登录
	const gotoLogin = () => {
		if (!isSelect) {
			return
		}
		if (isClick) {
      setIsClick(false)
			// 2021年4月份后新的获取微信用户信息接口
			if (Taro.canIUse('getUserProfile')) {
				Taro.getUserProfile({
					desc: '完善会员信息',
					success: function (res) {
						console.log("获取成功:", res)
						app.userInfo = res.userInfo;
					},
					fail: function (err) {
						console.log("获取失败: ", err)
					},
					complete: function () {
            setIsClick(true)
						Taro.navigateTo({
							url: '../login-phone/login-phone'
						})
						Taro.setStorageSync('isReaddeldgate', true)
					}
				})
			}
		} else {
			return
		}
	}
  return (
    <Block>
      <Image
        className='logo-div'
        mode='cover'
        src='https://yjk-aimdt-dev.oss-cn-shenzhen.aliyuncs.com/ImageFiles/resources/yd.png'
      ></Image>
      <View className='logo-title'>AI-MDT</View>
      <Image
        className='logo-img'
        mode='cover'
        src='https://yjk-aimdt-dev.oss-cn-shenzhen.aliyuncs.com/ImageFiles/resources/guidance.png'
      ></Image>
      <View className='login-main'>
        <View className='login-row' onClick={() =>selectedFn()} data-name='select'>
          {!isSelect && (
            <Image
              className='selected-img'
              mode='cover'
              src='https://yjk-aimdt-dev.oss-cn-shenzhen.aliyuncs.com/ImageFiles/resources/unselected.png'
            ></Image>
          )}
          {isSelect && (
            <Image
              className='selected-img'
              mode='cover'
              src='https://yjk-aimdt-dev.oss-cn-shenzhen.aliyuncs.com/ImageFiles/resources/selected.png'
            ></Image>
          )}
          <View className='reading' >
            阅读并同意
          </View>
          <View className='info'>
            <View className='policy' onClick={(e) =>policyFn(e,'agreement')}>
              《用户服务协议》
            </View>
            <View className='text'>与</View>
            <View className='policy' onClick={(e) =>policyFn(e,'privacy')}>
              《隐私政策》
            </View>
          </View>
        </View>

        <Button
          className='login-btn'
          openType={isSelect ? 'getPhoneNumber' : ''}
          style={'opacity: ' + opacity + ';'}
          onGetphonenumber={getPhoneNumberFn}
          onClick={() =>showError()}
        >
            我要登录
          </Button>
          {/* <View className='login-btn' onClick={() =>toScan()}>
            扫描门店码的临时入口
          </View> */}
      </View>
    </Block>

  )
}
export default definePageConfig({
  navigationBarTitleText: 'AI-AMD'
})

import { useState } from 'react';
import Taro, {useDidShow} from '@tarojs/taro'
import { Block, View, Input, Button } from '@tarojs/components'
import './login-phone.scss'
import {
  ApiFn
} from '../../../utils/request'

export default function LoginPhone() {
  const [opacity, setOpacity] = useState(0.4);
  const [phoneVal, setPhoneVal] = useState('');
  const [codeVal, setCodeVal] = useState('');
  const [tmplIds, setTmplIds] = useState('');
  
  useDidShow(()=>{
    getFindTemplate()
  })
  // 获取模板权限
  const getFindTemplate = ()=>{
    //通过接口获取订阅消息
    const accountInfo = Taro.getAccountInfoSync()
    const params = {
      appId: accountInfo.miniProgram.appId
    }
    ApiFn(
      'api/findTemplate',
      params,
      'GET',
      '加载中...'
    ).then(res=> {
      // console.log("获取消息模板接口" + JSON.stringify(res));
      if (res.result) {
        Taro.setStorageSync('templateList', res.result)
        const loginNeedTemplateType = [
          'QUESTION_ONE',
          'REPORT_SUCCESS',
          'CONSULTATION_PROGRESS'
        ] // 登录后需要获取的消息模板type

        const templateIdsList = res.result
          .filter(item => loginNeedTemplateType.includes(item.type))
          .map(item => item.templateId)
        setTmplIds(templateIdsList)
        return
      }
      setTmplIds([])
    })
  }
  const loginFn = ()=> {
    if(phoneVal && codeVal) {
      Taro.getSetting({
        withSubscriptions: true,
        success(res) {
          console.log('用户授权结果',res);
          // 通过接口获取订阅消息
          Taro.requestSubscribeMessage({
            tmplIds,
            success(res) {
              console.log('消息', res);
              // that.setData({
              //   SubscribeMessageRes: res
              // })
              goLogin();
            },
            fail(err) {
              console.log('订阅失败:' + JSON.stringify(err))
              goLogin();
            }
          })
        }
      })
    }
  }
  const goLogin = ()=> {
    Taro.login({
      success(res) {
        const accountInfo = Taro.getAccountInfoSync();
        const params = {
          phoneNumber: Number(phoneVal),
          verifyCode: Number(codeVal),
          code: res.code,
          appId: accountInfo.miniProgram.appId
        }
        ApiFn(
          'api/healthPassport/newLogin',
          params,
          'POSTText',
          '加载中...'
        ).then(res=> {
          const message = '登录成功'
          Taro.showToast({
            title: res.code == 0 ? message : res.message,
            icon: 'none',
            duration: 2000
          })
          const { mobile, sessionKey, status, vids, customerId } = res.result
          if (res.code == 0) {
            Taro.setStorageSync('sessionKey', sessionKey)
            Taro.setStorageSync('phoneNumber', mobile)
            if (res.result.perfectInfo) {
              // 信息不全需补齐
              return that.router2fillInfo(mobile)
            }
            if (status.indexOf('continue') != -1) {
              //跳转填写性别名字
              Taro.navigateTo({
                url: '../scantheSexAndName/scantheSexAndName'
              })
            } else {
              //跳转欢迎使用界面
              if (!vids || !vids.length) {
                if (!customerId) {
                  that.router2fillInfo(mobile)
                  return
                } else {
                  Taro.setStorageSync('newCustomerId', customerId)
                  Taro.setStorageSync('customerId', customerId)
                  Taro.reLaunch({
                    url: '/pages/index/index'
                  })
                }
              }
              // 当扫码含有vid时直接使用vid
              if (vids.length === 1) {
                const vid =
                  that.data.vid ||
                  vids[0].vid ||
                  Taro.getStorageSync('phoneNumber') // 空数组拦截  1直接进欢迎页 1以上去选择套餐
                Taro.setStorageSync('evaluateId', vids[0].evaluateId) // 增加评估id的缓存 取第一个
                // 埋点请求
                toBuriedPoints(1, vids[0].patientId)
                that.subscribeMessage(vid)
              } else if (vids.length > 1) {
                const vidsParams = JSON.stringify(vids) // 空数组拦截  1直接进欢迎页 1以上去选择套餐
                console.log('选择页面')
                Taro.reLaunch({
                  url: '../select-report/select-report?vids=' + vidsParams
                })
              }
            }
          }
        })
      }
    })
  }
  const phoneFn = (e)=> {
    setPhoneVal(e.detail.value)
    setOpacity(phoneVal && codeVal ? 1 : 0.4)

  }
  const codeFn = (e)=> {
    setCodeVal(e.detail.value)
    setOpacity(phoneVal && codeVal ? 1 : 0.4)
  }
  return (
    <Block>
      <View className='login-phone'>
        <View className='phone-header'>手机号码登录</View>
        <View className='login-item'>
          <View className='item-title'>手机号</View>
          <Input placeholder='请输入手机号码' type='number' value={phoneVal} maxlength={11} onInput={phoneFn} placeholderClass='tips-input' className='item-input' />
        </View>
        <View className='login-item'>
          <View className='item-title'>密码</View>
          <View className='flex-between'>
            <Input placeholder='请输入验证码' type='number' value={codeVal} maxlength={6} onInput={codeFn} placeholderClass='tips-input' className='item-input' />
            <Button className='item-code'>获取验证码</Button>
          </View>
        </View>
        <Button
          class='blue-btn login-btn'
          style={'opacity: ' + opacity + ';'}
          onClick={loginFn}
        >登录</Button>
      </View>
    </Block>
  )
}

import { useState, createContext } from 'react';
import { Block, View, Image, Text } from '@tarojs/components'
import Taro, {useDidShow} from '@tarojs/taro'
import './test.scss'

// import {
//   ApiFn
// } from '../../utils/request'
// import { toBuriedPoints } from '../../utils/request'

// const CountContext = createContext();


// const app = Taro.getApp();

export default function Login() {
  const [username, setUsername] = useState('hi tony');
  
  useDidShow(() => {
    toScan()
  })

  const toScan = ()=> {
    // Taro.showLoading();
    setUsername('hi jacky')
  }

  
  return (
    <Block>
      
    </Block>
  )
}
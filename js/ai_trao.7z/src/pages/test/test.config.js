export default definePageConfig({
  navigationBarTitleText: 'test'
})

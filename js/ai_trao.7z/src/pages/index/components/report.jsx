// import React from 'react';
// import { useContext } from 'react';
import Taro, {useDidShow} from '@tarojs/taro'
import { Block, View, Image, Button } from '@tarojs/components'
import './report.scss'
import { useState } from 'react';

function Report(props) {
  console.log('props', props)
  const [preUrl, setPreUrl] = useState('https://yjk-aimdt-dev.obs.cn-south-1.myhuaweicloud.com/ImageFiles/resource-new/img/');
  const [reportArray, setReportArray] = useState([]);
  const [allReportList, setAllReportList] = useState([]);
  
  
  // 点击了解更多
  const learnMore= () => {
    Taro.navigateTo({
      url: `/pages/goods/goods-detail/goods-detail?type=mdt`
    });
  }

  // 全部报告
  const allReportFn = () => {
  }

  // const reportArray = useContext(CountContext);
  return (
    <Block>
      <View className='report-block'>
        <Image className='report-bg' mode='widthFix' src={preUrl+'bg-report-patient.png'}></Image>
        {
          reportArray.length ? (
            <View className='report-info flex justify-between'>
              <View className='left'>
                <View className='report-title'> AI-MDT报告 </View>
                <View className='report-time'> { reportArray[0]['realtime'] } </View>
              </View>
              <View className='right'>
                <Button className='report-btn' data-item='{{reportArray[0]}}' onClick='itemClickReport'> { reportArray[0]['linkname'] } &gt;</Button>
              </View>
            </View>
            // <View className={allReportList.length > 1 ? 'report-botton-line report-botton' : 'report-botton'}>
            //   <Button className="report-btn-item" onClick="{()=>learnMore()}">购买报告</Button>
            //   {allReportList.length > 1 ? <Button className="report-btn-item" onClick="allReportFn" wx:if="{{}}">全部报告({{allReportList.length}})</Button> : ''}
            // </View>
          ) : (
            <Block>
              <View className='report-info'>
                <View className='left'>
                  <View className='report-title'> AI-MDT报告 </View>
                  <View className='report-none'>暂无报告</View>
                </View>
              </View>
              <View className={allReportList.length ? 'report-botton report-botton-line' : 'report-botton'}>
                <Button className='report-btn-item' onClick={() =>learnMore()}> 购买报告 </Button>
                {allReportList.length ? (
                  <Button className='report-btn-item' onClick={() =>allReportFn()}>全部报告({allReportList.length})</Button>
                ) : ''}
                
              </View>
            </Block>
          )}
      </View>
    </Block>
  );
}

export default Report;
Report.defaultProps = {
  reportArray: [],
}

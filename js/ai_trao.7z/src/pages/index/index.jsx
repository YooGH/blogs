import { useState, createContext } from 'react';
import { Block, View, Image, Text } from '@tarojs/components'
import Taro, {useDidShow} from '@tarojs/taro'
import './index.scss'
import Report from './components/report.jsx'

import {
  ApiFn
} from '../../utils/request'
// import { toBuriedPoints } from '../../utils/request'

// const CountContext = createContext();


// const app = Taro.getApp();

export default function Login() {
  // 声明一个新的叫做 “count” 的 state 变量
  const [username, setUsername] = useState('hi tony');
  const [vid, setVid] = useState('');
  const [reportArray, setReportArray] = useState([]);
  const [preUrl, setPreUrl] = useState('https://yjk-aimdt-dev.obs.cn-south-1.myhuaweicloud.com/ImageFiles/resource-new/img/');
  const [vajraList, setVajraList] = useState([
    //识别start
    {id: 0, title: '预约体检', url: 'yytj.png', route: '/pages/medical/medical-list/medical-list', },
    {id: 1, title: '团检登记', url: 'medical-group.png', route: '/pages/medical/medical-corporation/medical-corporation', },
    //识别end
    {id: 2, title: '定制体检', url: 'medical-customized.png', route: '/pages/medical/medical-programme/medical-programme', },
    {id: 3, title: '报告查询', url: 'bgcx.png', route: '/pages/aftersale/report-own/report-own', },
  ]);
  
  useDidShow(() => {
    toScan()
    getNewData()
  })

  const toScan = ()=> {
    // Taro.showLoading();
    setUsername('hi jacky')
  }
  // 获取首页数据
  const getNewData = ()=>{
    const vid = vid || Taro.getStorageSync('vid') || ''
    const params = {
      vid,
      orgId: Taro.getStorageSync('orgId')
    };
    ApiFn(
      "api/evaluateInfo/newEvalList",
      params,
      'GET',
      '加载中...'
    ).then(res=> {
      setReportArray(res.result.list)
    })
  }

  // 金刚区跳转
  const vajraFn = (info) => {
    // if(appData && !appData.loginStatus) { return Taro.navigateTo({
    //   url: `/pages/aftersale/not-login/not-login?title=${info.title}`,
    // })}
    Taro.navigateTo({
      url: info.route,
    })
  }

  
  return (
    <Block>
      <View className='index-container'>
        {/* AI-MDT报告 */}
        <Report reportArray={reportArray} />
        {/* 金刚区 */}
        <View className='vajra-district'>
          {vajraList.map(item=>
            <View
              className='vajra-item'
              onClick={()=>vajraFn(item)}
            >
              <Image className='vajra-logo' mode='cover' src={preUrl+item.url} />
              <Text className='vajra-title'>{item.title}</Text>
            </View>
          )}
          
        </View>
      </View>
    </Block>
  )
}
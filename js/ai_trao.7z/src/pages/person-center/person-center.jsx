import { useState } from 'react';
import { Block, View } from '@tarojs/components'
import Taro, {useDidShow} from '@tarojs/taro'
import './person-center.scss'

export default function PersonCenter() {
  // 声明一个新的叫做 “count” 的 state 变量
  const [username, setUsername] = useState('hi tony');
  
 
  useDidShow(() => {
    toScan()
  })

  const toScan = ()=> {
    Taro.showLoading();
    setUsername('hi jack')
  }
  
  return (
    <Block>
      <View>{username}</View>
    </Block>
  )
}
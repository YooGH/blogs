export default definePageConfig({
  navigationBarTitleText: '套餐详情'
})

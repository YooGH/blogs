// import React from 'react';
// import { useContext } from 'react';
import Taro, {useDidShow, ComponentWillMount} from '@tarojs/taro'
import { Block, View, Image, Swiper, SwiperItem } from '@tarojs/components'
import './goods-swiper.scss'
import { useState } from 'react';

function Report(props) {
  console.log('props', props.imgsList)
  const [current, setCurrent] = useState(0);
  const [indicatorDots, setIndicatorDots] = useState(false); // 不要点
  const [autoplay, setAutoplay] = useState(true); // 是否自动滚动
  const [circular, setCircular] = useState(true); // 衔接滚动
  const [interval, setInterval] = useState(3000); // 切换时间间隔
  const [duration, setDuration] = useState(500); // 动画时长
  const [imgList, setImgList] = useState([]); // 

  useDidShow(()=>{
    console.log('useDidShow')
  })


  // 全部报告
  const onChangeSwiper = () => {
  }

  return (
    <Block>
      <View className='swiper-block'>
        <Swiper
          className='swiper'
          onChange='onChangeSwiper'
          indicator-dots={indicatorDots}
          autoplay={autoplay}
          interval={interval}
          duration={duration}
          circular={circular}
        >
          {
            imgList.map(item => 
              <SwiperItem>
                <Image className='img-goods' src={item.filePath}></Image>
              </SwiperItem>
            )
          }
        </Swiper>
        <View className='img-page'>
          {`${1+current}/${imgList.length}`}
        </View>
      </View>
    </Block>
  );
}

export default Report;
// Report.defaultProps = {
//   imgList: [],
// }

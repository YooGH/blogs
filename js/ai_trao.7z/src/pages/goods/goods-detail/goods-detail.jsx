import { useState, createContext } from 'react';
import { Block, View, Image, Text } from '@tarojs/components'
import Taro, {useDidShow, getCurrentInstance} from '@tarojs/taro'
import './goods-detail.scss'

import {
  ApiFn
} from '../../../utils/request'
import {
  getMdtPackageList
} from '../../../utils/api'
// import { toBuriedPoints } from '../../utils/request'


// const CountContext = createContext();

import GoodsSwiper from './components/goods-swiper.jsx'

// const app = Taro.getApp();

export default function GoodsDetail() {
  const options = getCurrentInstance().router.params
  const [username, setUsername] = useState('hi tony');
  const [payBtnText, setPayBtnText] = useState('');
  const [MDTObj, setMDTObj] = useState({});
  const [imgsList, setImgsList] = useState([]);
  const [backToGoodStatus, setBackToGoodStatus] = useState(0); // v2.18 
  const [medicalOrderId, setMedicalOrderId] = useState(''); // v2.18 

  useDidShow(() => {
    if (options.type === 'mdt') { // AIMDT
      setPayBtnText('立即购买')
      setMDTObj({
        orgId: options.orgId, // 2.16
        patientId: options.patientId || '', // 2.16
        orderNo: options.orderNo, // 2.10
        findMedicalReportHistoryId: options.findMedicalReportHistoryId, // 2.10
      })
  
      // 2.18 pjh 20220817
      setBackToGoodStatus(options.backToGoodStatus)
      setMedicalOrderId(options.medicalOrderId)
  
      getMdtPackageListFn(options.orgId);
    } else { // 个检或其他套餐
  
      // this.goodsId = options.id
      // this.getsetMealDetailFn();
    }
    // Taro.getSystemInfo().then(res => {
    //   this.setData({
    //     safeAreaHeight: res.screenHeight - res.safeArea.bottom
    //   })
    // })
  })

  // mdt套餐
  const getMdtPackageListFn = (orgId)=> {
    // Taro.showLoading();
    ApiFn(
      getMdtPackageList, {
        orgId: orgId || Taro.getStorageSync('orgId') || '999'
      },
      'GET',
      '',
    ).then(res => {
      // console.log()
      showInfoFn(res.result)
      // this.showInfoFn(res);
      // this.track(res.result)
    })
  }

  const showInfoFn = (info) => {
    console.log(info)
    setImgsList(info.goodsMainImgList)
  }

  
  return (
    <Block>
      <GoodsSwiper imgsList={imgsList} />
    </Block>
  )
}
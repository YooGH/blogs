import { ADD, INCREASE } from '../constants/counter.js'

const INITIAL_STATE = {
    num: 0,
    vidsList: []
}

export default function counter(state = INITIAL_STATE, action) {
    switch (action.type) {
        case ADD:
            return {
                ...state,
                num: state.num + 1
            }
        case INCREASE:
            console.log('jjjjj1', action)
            state.vidsList = action.vids
            // return {
            //     ...state,
            //     vidsList: 
            // }

        default:
            return state
    }
}
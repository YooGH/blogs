import { combineReducers } from 'redux'

import user from './counter'

export default combineReducers({
  user,
})
export const ADD = 'ADD';
export const INCREASE = 'INCREASE';

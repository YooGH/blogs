const fs = require('fs');

let dirData = null;
const url = './old.txt';
function dirTurnObj() { // 读目录转对象
  dirData = fs.readFileSync(url, 'utf8');
  console.log()
}

// let dirData = '';
function objTurnStr() {  // 对象转字符串
  if(!dirData) {return}


  // 事件
  dirData = dirData.replace(/bindtap/g, "onClick"); // 需要把分号去掉

  // 双向绑定{{}} => {}
  dirData = dirData.replace(/"{{/g, "{");
  dirData = dirData.replace(/}}"/g, "}");

  dirData = dirData.replace(/wx:/g, "");
  

  // bingchange => onChange
  let event = dirData.match(/bind\w{1}/g);
  for(let item of event) {
    dirData = dirData.replace(item, 'on' + item.substr(item.length-1).toUpperCase());
  }


  // html标签首字母大写
  let leftTag = dirData.match(/<\w/g);
  for(let item of leftTag) {
    dirData = dirData.replace(item, item.toUpperCase());
  }
  let rightTag = dirData.match(/<\/\w/g);
  for(let item of rightTag) {
    dirData = dirData.replace(item, item.toUpperCase());
  }

  // 样式
  dirData = dirData.replace(/class=/g, "className=");

  




  // JS
  dirData = dirData.replace(/wx/g, "Taro"); // 
  // dirData = dirData.replace(/() {/, " = () => {"); // 
  


  return dirData;
}



dirTurnObj();
objTurnStr();
setTimeout(()=> {
  fs.writeFile(`./new.txt`, dirData, err => {
    if (err) throw err;
    console.log('写入成功');
  });
}, 2000)
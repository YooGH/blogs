module.exports = {
  url: "https://betaapi2.zkaimdt.com/",
  webViewUrl: "https://betareport2.zkaimdt.com/aimdtH5/#/"
}
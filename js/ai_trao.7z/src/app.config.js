export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/goods-center/goods-center',
    'pages/person-center/person-center',
    'pages/login/login/login',
    'pages/login/login-phone/login-phone',
    'pages/login/select-report/select-report',
    'pages/test/test'
  ],
  subPackages: [
    {
      root: "pages/goods",
      name: "goods",
      pages: [
        "goods-detail/goods-detail",
      ]
    }
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: 'WeChat',
    navigationBarTextStyle: 'black'
  },
  tabBar: {
    borderStyle: "black",
    backgroundColor: "#fff",
    color: "#37352F",
    selectedColor: "#4DA9FB",
    list: [
      {
        pagePath: "pages/index/index",
        text: '首页',
        iconPath: "static/img/aimdt.png",
        selectedIconPath: "static/img/aimdt_selected.png",
      },
      {
        pagePath: "pages/test/test",
        text: '任务',
        iconPath: "static/img/task.png",
        selectedIconPath: "static/img/task_selected.png",
      },
      {
        pagePath: "pages/goods-center/goods-center",
        text: '商城',
        iconPath: "static/img/shoppingmall.png",
        selectedIconPath: "static/img/shoppingmall_selected.png",
      },
      {
        pagePath: "pages/person-center/person-center",
        text: '个人',
        iconPath: "static/img/my.png",
        selectedIconPath: "static/img/my_selected.png",
      }
    ]
  },
})

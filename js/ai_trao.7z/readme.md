﻿﻿路由文件： app.config.js


开发环境小程序执行``yarn dev:weapp``


onclick={()=>{fn()}}不能onclick={fn()}不然会马上执行




登录
选评估
首页
商品详情（）
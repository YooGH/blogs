版本：vue2,vue-router3,vuex3

1. 脚手架``npm install -g @vue/cli``
2. 创建vue``vue create 项目名称``
3. 搭建两个页面
       ①. 安装：npm install --save vue-router@3  （解决办法是安装命令改为 npm install --save vue-router@3;  vue2中使用的vue-router是3版本，同理vue3中安装4版本的vue-router ）
       ②. 创建router文件：router-index.js（代码1）,设置main和App.vue(代码2)
       ③. 创建页面文件: view--page1.vue; view--page1.vue(代码3)
4. 创建vuex
       ①. 安装：npm install vuex@3
       ②. 创建vuex文件：store-index.js（代码4）,设置main(代码5)
       ③. 直接vuex应用（代码6）--this.$store['state'/'commit'/'dispatch']
       ③. 引入vuex应用（代码7）--映射->import {mapState, mapMutations, mapActions} from 'vuex'
       ③. 二级vuex应用（代码8）--namespaced: true(store-user.js)
       ③. 二级vuex应用2（代码9）--import {createNamespacedHelpers} from 'vuex'('page4.vue')




<!-- 代码1 -->
<!-- router-index.js -->
```
import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router)

import page1 from '../view/page1.vue'
import page2 from '../view/page2.vue'

export default new Router({
  routes: [
    {
      path: '/',
      name: 'page1',
      component: page1
    },
    {
      path: '/page2',
      name: 'page2',
      component: page2
    },
  ]
})
```


<!-- 代码2 -->
```
import Vue from 'vue'
import App from './App.vue'
import router from './router';    // 引入router

Vue.config.productionTip = false

new Vue({
  router,                         // 导入router
  render: h => h(App),
}).$mount('#app')
```


```
<template>
  <div id="app">
    <router-view></router-view>             <!-- 更改成路由组件 -->
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
```


<!-- 代码3 -->

```
<template>
  <div @click="getPage2">
    Hi
  </div>
</template>

<script>
export default {
  name: 'page1',
  data() {
    return {

    }
  },
  methods: {
    getPage2() {
      this.$router.push('page2')
    }
  }
}
</script>
```

```
<template>
  <div @click="goBack">
    Hi2
  </div>
</template>

<script>
export default {
  name: 'page2',
  data() {
    return {

    }
  },
  methods: {
    goBack() {
      this.$router.back()
    }
  }
}
</script>
```

<!-- 代码4 -->
```
import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex)
export default new Vuex.Store({
  state: {
    name: 'cc',
  },
  
  getters: {
  
  },
  
  mutations: {
    setName(state, data) {
      console.log(data)
      state.name = data;
    }
  },
  
  actions: {
    updateName({ commit }, data) {
      console.log('j',data)
      setTimeout(()=>{
        commit('setName', data)
      }, 1000)
    }

  },
  
})
```

<!-- 代码5 -->

```
import Vue from 'vue'
import App from './App.vue'
import router from './router';
import store from './store';        // 引入vuex

Vue.config.productionTip = false

new Vue({
  router,
  store,                            // 导入vuex
  render: h => h(App),
}).$mount('#app')

```

<!-- 代码6：page1.vue -->

```
<template>
  <div @click="getPage2">
    Hi,{{names}}
  </div>
</template>

<script>
export default {
  name: 'page1',
  computed: {
    names() {
      return this.$store.state.name
    }
  },
  mounted() {
    this.$store.commit('setName', 'heer')
    this.$store.dispatch('updateName', 'hail')
  },
  methods: {
    getPage2() {
      this.$router.push('page2')
    }
  }
}
</script>
```


<!-- 代码7：page2.vue -->

```
<template>
  <div @click="goBack">
    Hello, {{name}}
  </div>
</template>

<script>
import {
  mapState,
  mapMutations,
  mapActions
} from 'vuex'      // vuex按需引入
export default {
  name: 'page2',
  computed: {
    ...mapState(['name'])  // state
  },
  mounted() {
    this.setName('c1')
    this.updateName('c2')
  },
  methods: {
    ...mapMutations(['setName']),  // mutaions
    ...mapActions(['updateName']), // actions
    goBack() {
      this.$router.back()
    }
  }
}
</script>
```


<!-- 代码8：store-user.js -->

```
const state = {
  sex: ''
}

const mutations = {
  setSex(state, data) {
    state.sex = data;
  }
}

const actions = {
  updateSex({ commit }, data) {
    setTimeout(()=>{
      commit('setSex', data)
    }, 1000)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
};
```

<!-- 代码8：store-index.js -->
```
......
import user from './user.js'
export default new Vuex.Store({
  ......
  
  modules: {
    user
  }
})
```

<!-- 代码8：store-view-page3.vue -->

```
<template>
  <div>
    性别：{{sex}}
  </div>
</template>

<script>
import {
  mapState,
  mapMutations,
  mapActions
} from 'vuex'
export default {
  name: 'page3',
  computed: {
    ...mapState('user',['sex'])  // 获取二级store的state
  },
  mounted() {
    this.setSex('男')
    this.updateSex('女')
    console.log(this.$store.state.user.sex)
  },
  methods: {
    ...mapMutations('user',['setSex']),  // 获取二级store的mutations
    ...mapActions('user',['updateSex']), // 获取二级store的actions
  }
}
</script>
```

<!-- 代码9：page4.vue -->

```
<template>
  <div>
    性别：{{sex}}
  </div>
</template>

<script>
import {createNamespacedHelpers} from 'vuex'   // createNamespacedHelpers--二级store
  const {
    mapState,
    mapMutations,
    mapActions
  } = createNamespacedHelpers('user')
export default {
  name: 'page4',
  computed: {
    ...mapState(['sex'])
  },
  mounted() {
    this.setSex('男')
    this.updateSex('女')
    console.log(this.$store.state.user.sex)  // 直接获取二级的state
  },
  methods: {
    ...mapMutations(['setSex']),
    ...mapActions(['updateSex']),
  }
}
</script>
```

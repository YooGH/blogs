<template>
  <div @click="getPage2">
    Hi,{{names}}
  </div>
</template>

<script>
export default {
  name: 'page1',
  computed: {
    names() {
      return this.$store.state.name
    }
  },
  mounted() {
    this.$store.commit('setName', 'heer')
    this.$store.dispatch('updateName', 'hail')
  },
  methods: {
    getPage2() {
      this.$router.push('page2')
    }
  }
}
</script>


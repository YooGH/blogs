<template>
  <div @click="goBack">
    Hello, {{name}}
  </div>
</template>

<script>
import {
  mapState,
  mapMutations,
  mapActions
} from 'vuex'      // vuex按需引入
export default {
  name: 'page2',
  computed: {
    ...mapState(['name'])  // state
  },
  mounted() {
    this.setName('c1')
    this.updateName('c2')
  },
  methods: {
    ...mapMutations(['setName']),  // mutaions
    ...mapActions(['updateName']), // actions
    goBack() {
      this.$router.back()
    }
  }
}
</script>


<template>
  <div>
    性别：{{sex}}
  </div>
</template>

<script>
import {createNamespacedHelpers} from 'vuex'   // createNamespacedHelpers--二级store
  const {
    mapState,
    mapMutations,
    mapActions
  } = createNamespacedHelpers('user')
export default {
  name: 'page4',
  computed: {
    ...mapState(['sex'])
  },
  mounted() {
    this.setSex('男')
    this.updateSex('女')
    console.log(this.$store.state.user.sex)  // 直接获取二级的state
  },
  methods: {
    ...mapMutations(['setSex']),
    ...mapActions(['updateSex']),
  }
}
</script>


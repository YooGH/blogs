<template>
  <div>
    性别：{{sex}}
  </div>
</template>

<script>
import {
  mapState,
  mapMutations,
  mapActions
} from 'vuex'
export default {
  name: 'page3',
  computed: {
    ...mapState('user',['sex'])  // 获取二级store的state
  },
  mounted() {
    this.setSex('男')
    this.updateSex('女')
    console.log(this.$store.state.user.sex)
  },
  methods: {
    ...mapMutations('user',['setSex']),  // 获取二级store的mutations
    ...mapActions('user',['updateSex']), // 获取二级store的actions
  }
}
</script>


const state = {
  sex: ''
}

const mutations = {
  setSex(state, data) {
    state.sex = data;
  }
}

const actions = {
  updateSex({ commit }, data) {
    setTimeout(()=>{
      commit('setSex', data)
    }, 1000)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
};
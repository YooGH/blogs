import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex)
import user from './user.js'
export default new Vuex.Store({
  state: {
    name: 'cc',
  },
  
  getters: {
  
  },
  
  mutations: {
    setName(state, data) {
      console.log(data)
      state.name = data;
    }
  },
  
  actions: {
    updateName({ commit }, data) {
      console.log('j',data)
      setTimeout(()=>{
        commit('setName', data)
      }, 1000)
    }

  },
  
  modules: {
    user
  }
})